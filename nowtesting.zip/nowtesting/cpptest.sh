cript tells shell to install softwares here

apt-get update

apt-get install firefox -y

apt-get install eclipse -y

apt-get install geany -y

apt-get install xrdp -y

apt-get install icewm -y

apt-get install idesk -y

apt-get install dpkg -y

apt-get install rox-filer -y

apt-get install scp -y

apt-get install xterm -y

apt-get install zip -y

apt-get install unzip -y

apt-get install nautilus -y

#here script install php-bind and apache2:-

apt-get install apache2 mariadb-server php7.0 php7.0-mysql php7.0-gd php7.0-curl php7.0-imap libapache2-mod-php7.0 php7.0-mcrypt php7.0-xml php7.0-json -y

apt-get install apache2 -y

systemctl stop apache2.service

sudo systemctl start apache2.service

sudo systemctl enable apache2.service

#script create linkfiles:-

cp /root/C.png /usr/share/pixmaps

ln -s /usr/share/icons/hicolor/16x16/apps/firefox.png /usr/share/pixmaps/firefox.png

ln -s /usr/share/icons/hicolor/16x16/apps/eclipse.png /usr/share/pixmaps/eclipse.png

#ln -s /usr/share/pixmaps/rox-filer.png rox-filer.png

ln -s /opt/Adobe/Reader9/Resource/Icons/16x16/adobe.pdf.png /usr/share/pixmaps/adobereader.png

ln -s /usr/share/icons/hicolor/256x256@2x/apps/codelite.png /usr/share/pixmaps/codelite.png

ln -s /usr/share/icons/hicolor/16x16/apps/geany.png /usr/share/pixmaps/geany.png

#hear script perform directory struchure:-

mkdir /home/ubuntu/backup

mkdir /home/ubuntu/backup/handson
mkdir /home/ubuntu/backup/slides
mkdir /home/ubuntu/backup/outline
mkdir /home/ubuntu/backup/backup

touch /home/ubuntu/backup/instructions

cp /root/menu /usr/share/icewm/menu 

mkdir /home/ubuntu/.icewm

mkdir /home/ubuntu/.idesktop

#scp 172.31.6.36/home/ubuntu/.icewm/startup /home/ubuntu/.icewm/startup

cp /root/.ideskrc /home/ubuntu/.ideskrc

cp /root/.idesktop/* /home/ubuntu/.idesktop

echo "idesk >> /tmp/idesklog &" > /home/ubuntu/.icewm/startup

chmod +x /home/ubuntu/.icewm/startup 

#hear script tells to install cpp required packages

apt-get update

apt-get install g++ -y

#hear the script tell to install Adobe reader to pdf docs:-

add-apt-repository "deb http://archive.canonical.com/ precise partner"

apt-get update

apt-get install adobereader-enu -y                             

# here the scrit will install codelite 

sh -c `echo "deb http://repos.codelite.org/ubuntu/ xenial universe" >> /etc/apt/sources.list.d/codelite/list`

apt-key adv --fetch-keys http://repos.codelite.org/codelite.asc

apt-get update

apt-get install codelite wxcrafter -y

apt-get install codelite=9.1* -y

exit 0

