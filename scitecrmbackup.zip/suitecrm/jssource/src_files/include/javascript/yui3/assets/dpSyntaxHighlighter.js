// This file has been removed as the license is incompatible with Sugar's.
// AFAIK this file is only used with YUI3 charts.